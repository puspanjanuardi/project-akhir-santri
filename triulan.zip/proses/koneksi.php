<?php
$connect = mysqli_connect("sql127.main-hosting.eu", "u925156864_farid", " Farid1234", "u925156864_farid");
?>